#!/bin/sh
# TrioWidget 설치: 앱을 /Applications 로 옮기고, 인터넷에서 받은 표시(격리)를 지우고, 실행해요.
cd "$(dirname "$0")"
pkill -x TrioWidget 2>/dev/null
rm -rf /Applications/TrioWidget.app
cp -R TrioWidget.app /Applications/ && xattr -dr com.apple.quarantine /Applications/TrioWidget.app
open /Applications/TrioWidget.app
echo ""
echo "설치 끝! 이제 SWx2 → 프로필 → MCP 연결 → Mac 위젯 → '위젯 연결 만들기' → 'TrioWidget 에 연결' 을 눌러요."
echo "알림 허용 창이 뜨면 '허용'을 눌러 주세요. 이 창은 닫아도 돼요."
